// =====================================================
// EDGE FUNCTION UNIFICADA COMPLETA: PROPERTY SEARCH & DETAIL
// Archivo: supabase/functions/unified-property-search/index.ts
// Con lógica completa de proyectos, búsqueda por tags Y contenido específico
// =====================================================
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';
const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS'
};
// =====================================================
// UTILIDADES BÁSICAS (DEFINIDAS PRIMERO)
// =====================================================
function formatCurrency(amount, currency = 'USD') {
  if (!amount) return 'Precio a consultar';
  const symbol = currency === 'USD' ? 'US$' : 'RD$';
  return `${symbol}${amount.toLocaleString()}`;
}
function formatDuration(seconds) {
  if (!seconds) return null;
  const hours = Math.floor(seconds / 3600);
  const minutes = Math.floor(seconds % 3600 / 60);
  const remainingSeconds = seconds % 60;
  if (hours > 0) {
    return `${hours}:${minutes.toString().padStart(2, '0')}:${remainingSeconds.toString().padStart(2, '0')}`;
  } else {
    return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`;
  }
}
function calculateProjectCompletion(phases) {
  if (!phases || phases.length === 0) return 0;
  const phasesWithCompletion = phases.filter((phase)=>typeof phase.completion_percentage === 'number');
  if (phasesWithCompletion.length > 0) {
    const totalCompletion = phasesWithCompletion.reduce((sum, phase)=>sum + phase.completion_percentage, 0);
    return Math.round(totalCompletion / phasesWithCompletion.length);
  }
  const completedPhases = phases.filter((phase)=>phase.status === 'completed').length;
  return Math.round(completedPhases / phases.length * 100);
}
// =====================================================
// FUNCIONES DE CONTENIDO ESPECÍFICO (NUEVAS)
// =====================================================
async function getPropertySpecificContent(supabaseClient, propertyId) {
  console.log('🎯 === OBTENIENDO CONTENIDO ESPECÍFICO DE LA PROPIEDAD ===');
  console.log('📋 Property ID:', propertyId);
  try {
    // Consultar relaciones directas de contenido
    const { data: relations, error } = await supabaseClient.from('content_property_relations').select('content_id, content_type, relation_type, weight, notes').eq('property_id', propertyId).order('weight', {
      ascending: false
    });
    if (error) {
      console.error('❌ Error consultando content_property_relations:', error);
      return null;
    }
    if (!relations || relations.length === 0) {
      console.log('⚠️ No hay contenido específico, usando contenido general');
      return null;
    }
    console.log('📊 Relaciones encontradas:', relations.length);
    // Agrupar por tipo de contenido
    const contentByType = relations.reduce((acc, rel)=>{
      if (!acc[rel.content_type]) acc[rel.content_type] = [];
      acc[rel.content_type].push(rel);
      return acc;
    }, {});
    console.log('📊 Contenido específico agrupado:', {
      articles: contentByType.article?.length || 0,
      videos: contentByType.video?.length || 0,
      testimonials: contentByType.testimonial?.length || 0,
      faqs: contentByType.faq?.length || 0,
      seo_content: contentByType.seo_content?.length || 0
    });
    // Obtener el contenido real en paralelo
    const [specificVideos, specificArticles, specificTestimonials, specificFaqs, specificSeoContent] = await Promise.all([
      contentByType.video ? getVideosByIds(supabaseClient, contentByType.video.map((v)=>v.content_id)) : Promise.resolve([]),
      contentByType.article ? getArticlesByIds(supabaseClient, contentByType.article.map((a)=>a.content_id)) : Promise.resolve([]),
      contentByType.testimonial ? getTestimonialsByIds(supabaseClient, contentByType.testimonial.map((t)=>t.content_id)) : Promise.resolve([]),
      contentByType.faq ? getFaqsByIds(supabaseClient, contentByType.faq.map((f)=>f.content_id)) : Promise.resolve([]),
      contentByType.seo_content ? getSeoContentByIds(supabaseClient, contentByType.seo_content.map((s)=>s.content_id)) : Promise.resolve([])
    ]);
    console.log('✅ Contenido específico obtenido:', {
      articles: specificArticles.length,
      videos: specificVideos.length,
      testimonials: specificTestimonials.length,
      faqs: specificFaqs.length,
      seo_content: specificSeoContent.length
    });
    return {
      articles: specificArticles || [],
      videos: (specificVideos || []).map((video)=>({
          ...video,
          formatted_duration: formatDuration(video.duration),
          youtube_url: video.video_platform === 'youtube' && video.video_id ? `https://www.youtube.com/watch?v=${video.video_id}` : null,
          is_project_specific: true
        })),
      testimonials: (specificTestimonials || []).map((testimonial)=>({
          ...testimonial,
          content: testimonial.full_testimonial,
          client_title: testimonial.client_profession,
          is_project_specific: true
        })),
      faqs: (specificFaqs || []).map((faq)=>({
          ...faq,
          is_project_specific: true
        })),
      seo_content: (specificSeoContent || []).map((content)=>({
          ...content,
          content: content.seo_content,
          page_url: content.identifier,
          is_project_specific: true
        })),
      has_specific_content: true,
      relation_summary: contentByType
    };
  } catch (error) {
    console.error('❌ Error crítico obteniendo contenido específico:', error);
    return null;
  }
}
// Funciones auxiliares para obtener contenido por IDs
async function getVideosByIds(supabaseClient, videoIds) {
  if (!videoIds || videoIds.length === 0) return [];
  console.log('🎥 Obteniendo videos específicos:', videoIds.length);
  const { data, error } = await supabaseClient.from('videos').select(`
      id, title, description, video_slug, thumbnail, video_id, 
      video_platform, duration, views, category, featured,
      meta_title, meta_description, status, published_at, 
      created_at, updated_at, subtitle
    `).in('id', videoIds).eq('status', 'published');
  if (error) {
    console.error('❌ Error obteniendo videos por IDs:', error);
    return [];
  }
  return data || [];
}
async function getArticlesByIds(supabaseClient, articleIds) {
  if (!articleIds || articleIds.length === 0) return [];
  console.log('📰 Obteniendo artículos específicos:', articleIds.length);
  const { data, error } = await supabaseClient.from('articles').select(`
      id, title, slug, excerpt, content, featured_image,
      published_at, created_at, updated_at,
      meta_title, meta_description
    `).in('id', articleIds).eq('status', 'published');
  if (error) {
    console.error('❌ Error obteniendo artículos por IDs:', error);
    return [];
  }
  return data || [];
}
async function getTestimonialsByIds(supabaseClient, testimonialIds) {
  if (!testimonialIds || testimonialIds.length === 0) return [];
  console.log('💬 Obteniendo testimonios específicos:', testimonialIds.length);
  const { data, error } = await supabaseClient.from('testimonials').select(`
      id, slug, title, excerpt, full_testimonial, rating,
      client_name, client_avatar, client_location, client_verified,
      client_profession, featured_image, views, featured,
      meta_title, meta_description, status, published_at, created_at
    `).in('id', testimonialIds).eq('status', 'published');
  if (error) {
    console.error('❌ Error obteniendo testimonios por IDs:', error);
    return [];
  }
  return data || [];
}
async function getFaqsByIds(supabaseClient, faqIds) {
  if (!faqIds || faqIds.length === 0) return [];
  console.log('❓ Obteniendo FAQs específicos:', faqIds.length);
  const { data, error } = await supabaseClient.from('faqs').select(`
      id, question, answer, sort_order, category,
      created_at, updated_at, status
    `).in('id', faqIds).eq('status', 'published');
  if (error) {
    console.error('❌ Error obteniendo FAQs por IDs:', error);
    return [];
  }
  return data || [];
}
async function getSeoContentByIds(supabaseClient, seoIds) {
  if (!seoIds || seoIds.length === 0) return [];
  console.log('🔍 Obteniendo contenido SEO específico:', seoIds.length);
  const { data, error } = await supabaseClient.from('seo_content').select(`
      id, title, description, h1_title, h2_subtitle, 
      seo_content, content_type, identifier,
      location_context, property_type_context, operation_context,
      views, performance_score, version, status,
      created_at, updated_at
    `).in('id', seoIds).eq('status', 'published');
  if (error) {
    console.error('❌ Error obteniendo contenido SEO por IDs:', error);
    return [];
  }
  return data || [];
}
function combineSpecificAndGeneralContent(specificContent, defaultContent) {
  console.log('🔄 === COMBINANDO CONTENIDO ESPECÍFICO Y GENERAL ===');
  if (!specificContent || !specificContent.has_specific_content) {
    console.log('⚠️ No hay contenido específico, usando solo contenido general');
    return {
      ...defaultContent,
      content_source: 'general_only'
    };
  }
  const combined = {
    // Priorizar contenido específico, completar con general si es necesario
    articles: [
      ...specificContent.articles,
      ...defaultContent.articles.slice(0, Math.max(0, 5 - specificContent.articles.length))
    ],
    videos: [
      ...specificContent.videos,
      ...defaultContent.videos.slice(0, Math.max(0, 4 - specificContent.videos.length))
    ],
    testimonials: [
      ...specificContent.testimonials,
      ...defaultContent.testimonials.slice(0, Math.max(0, 3 - specificContent.testimonials.length))
    ],
    faqs: [
      ...specificContent.faqs,
      ...defaultContent.faqs.slice(0, Math.max(0, 6 - specificContent.faqs.length))
    ],
    seo_content: [
      ...specificContent.seo_content,
      ...defaultContent.seo_content.slice(0, Math.max(0, 3 - specificContent.seo_content.length))
    ],
    // Mantener contenido general para el resto
    zone_testimonials: defaultContent.zone_testimonials,
    zone_videos: defaultContent.zone_videos,
    zone_faqs: defaultContent.zone_faqs,
    zone_articles: defaultContent.zone_articles,
    featured_content: defaultContent.featured_content,
    success_stories: defaultContent.success_stories,
    // Metadatos adicionales
    content_source: 'specific_and_general',
    specific_content_summary: {
      total_specific_items: (specificContent.articles?.length || 0) + (specificContent.videos?.length || 0) + (specificContent.testimonials?.length || 0) + (specificContent.faqs?.length || 0),
      relation_types: Object.keys(specificContent.relation_summary || {})
    }
  };
  console.log('✅ Contenido combinado exitosamente:', {
    articles: `${specificContent.articles.length} específicos + ${combined.articles.length - specificContent.articles.length} generales`,
    videos: `${specificContent.videos.length} específicos + ${combined.videos.length - specificContent.videos.length} generales`,
    testimonials: `${specificContent.testimonials.length} específicos + ${combined.testimonials.length - specificContent.testimonials.length} generales`,
    faqs: `${specificContent.faqs.length} específicos + ${combined.faqs.length - specificContent.faqs.length} generales`
  });
  return combined;
}
// =====================================================
// FUNCIONES DE PROYECTO (EXISTENTES - SIN CAMBIOS)
// =====================================================
async function getCompleteProjectDetailsWithFallback(supabaseClient, property) {
  console.log('🏗️ === OBTENIENDO DETALLES DEL PROYECTO CON FALLBACK ===');
  console.log('🔍 DEBUG INICIAL:', {
    property_id: property.id,
    is_project: property.is_project,
    project_detail_id: property.project_detail_id
  });
  if (property.project_detail_id) {
    console.log('✅ Usando project_detail_id:', property.project_detail_id);
    return await getCompleteProjectDetails(supabaseClient, property.project_detail_id);
  }
  if (property.is_project) {
    console.log('🔍 Buscando project_details por property_id:', property.id);
    try {
      const { data: projectSearch, error } = await supabaseClient.from('project_details').select('id, name, property_id').eq('property_id', property.id);
      console.log('🔍 Resultado búsqueda project_details:', {
        found: projectSearch?.length || 0,
        error: error?.message,
        results: projectSearch
      });
      if (!error && projectSearch && projectSearch.length > 0) {
        const project = projectSearch[0];
        console.log('✅ Encontrado project_detail_id por property_id:', project.id);
        return await getCompleteProjectDetails(supabaseClient, project.id);
      }
      console.log('🔍 Buscando project_details por nombre/código similar...');
      const { data: nameSearch, error: nameError } = await supabaseClient.from('project_details').select('id, name, property_id').ilike('name', `%${property.name?.split(' ')[0] || ''}%`).limit(5);
      console.log('🔍 Resultado búsqueda por nombre:', {
        found: nameSearch?.length || 0,
        error: nameError?.message,
        results: nameSearch
      });
      if (!nameError && nameSearch && nameSearch.length > 0) {
        const project = nameSearch[0];
        console.log('✅ Encontrado project_detail_id por nombre:', project.id);
        return await getCompleteProjectDetails(supabaseClient, project.id);
      }
      console.log('❌ No se encontró project_details para esta propiedad de ninguna manera');
      return null;
    } catch (error) {
      console.error('❌ Error buscando project_details:', error);
      return null;
    }
  }
  console.log('⚠️ Propiedad no es proyecto');
  return null;
}
async function getCompleteProjectDetails(supabaseClient, projectDetailId) {
  if (!projectDetailId) {
    console.log('⚠️ No project_detail_id proporcionado');
    return null;
  }
  console.log('🏗️ === OBTENIENDO DETALLES COMPLETOS DEL PROYECTO ===');
  console.log('📋 Project Detail ID:', projectDetailId);
  try {
    console.log('🔍 PASO 1: Verificando project_details básico...');
    const { data: basicProject, error: basicError } = await supabaseClient.from('project_details').select('*').eq('id', projectDetailId).single();
    console.log('📊 RESULTADO project_details básico:', {
      found: !!basicProject,
      error: basicError?.message,
      project_name: basicProject?.name,
      developer_id: basicProject?.developer_id
    });
    if (basicError || !basicProject) {
      console.error('❌ Error en project_details básico:', basicError);
      return null;
    }
    console.log('🔍 PASO 2: Consultando con relaciones...');
    const { data: projectData, error } = await supabaseClient.from('project_details').select(`
        *,
        developers!project_details_developer_id_fkey(id, name, legal_name, description, biography, website, email, phone, instagram_url, facebook_url, linkedin_url, logo_url, cover_image_url, years_experience, total_projects, total_units_delivered, slug, is_active, created_at, updated_at),
        project_typologies!project_typologies_project_id_fkey(
          id, project_id, name, description, bedrooms, bathrooms, built_area, balcony_area, total_area,
          sale_price_from, sale_price_to, sale_currency, total_units, available_units, is_sold_out, sold_out_date, sort_order, created_at
        ),
        project_amenities!project_amenities_project_id_fkey(
          id, amenity_id, description, category, included,
          amenities!project_amenities_amenity_id_fkey(id, name, icon, category, description)
        ),
        project_payment_plans!project_payment_plans_project_id_fkey(
          id, project_id, plan_name, description, reservation_amount, reservation_currency,
          separation_percentage, construction_percentage, construction_frequency, delivery_percentage,
          benefits, is_default, is_active, created_at
        ),
        project_phases!project_phases_project_id_fkey(
          id, project_id, phase_name, description, construction_start, estimated_delivery, actual_delivery,
          total_units, available_units, status, completion_percentage, sort_order, created_at
        )
      `).eq('id', projectDetailId).single();
    console.log('📊 RESULTADO consulta completa:', {
      error: error?.message,
      hasData: !!projectData,
      projectName: projectData?.name,
      developer: projectData?.developers?.name,
      typologiesCount: projectData?.project_typologies?.length || 0,
      amenitiesCount: projectData?.project_amenities?.length || 0,
      paymentPlansCount: projectData?.project_payment_plans?.length || 0,
      phasesCount: projectData?.project_phases?.length || 0
    });
    if (error) {
      console.error('❌ Error en consulta completa:', error);
      console.log('🔄 FALLBACK: Consultando relaciones por separado...');
      const [developers, typologies, amenities, paymentPlans, phases] = await Promise.all([
        supabaseClient.from('developers').select('*').eq('id', basicProject.developer_id).single(),
        supabaseClient.from('project_typologies').select('*').eq('project_id', projectDetailId),
        supabaseClient.from('project_amenities').select('*, amenities(*)').eq('project_id', projectDetailId),
        supabaseClient.from('project_payment_plans').select('*').eq('project_id', projectDetailId),
        supabaseClient.from('project_phases').select('*').eq('project_id', projectDetailId)
      ]);
      console.log('📊 RESULTADO consultas separadas:', {
        developer: developers.data?.name || 'No encontrado',
        typologies: typologies.data?.length || 0,
        amenities: amenities.data?.length || 0,
        paymentPlans: paymentPlans.data?.length || 0,
        phases: phases.data?.length || 0
      });
      const combinedProject = {
        ...basicProject,
        developers: developers.data,
        project_typologies: typologies.data || [],
        project_amenities: amenities.data || [],
        project_payment_plans: paymentPlans.data || [],
        project_phases: phases.data || []
      };
      return await enrichProjectData(combinedProject);
    }
    if (!projectData) {
      console.log('⚠️ No se encontraron datos del proyecto');
      return null;
    }
    console.log('✅ Datos del proyecto obtenidos exitosamente');
    return await enrichProjectData(projectData);
  } catch (error) {
    console.error('❌ Error crítico en getCompleteProjectDetails:', error);
    return null;
  }
}
async function enrichProjectData(projectData) {
  console.log('🎨 Enriqueciendo datos del proyecto...');
  const enrichedProject = {
    ...projectData,
    amenities_by_category: projectData.project_amenities?.reduce((acc, amenity)=>{
      const category = amenity.amenities?.category || 'general';
      if (!acc[category]) acc[category] = [];
      acc[category].push({
        id: amenity.amenities?.id,
        name: amenity.amenities?.name,
        icon: amenity.amenities?.icon,
        description: amenity.description || amenity.amenities?.description,
        included: amenity.included
      });
      return acc;
    }, {}) || {},
    typologies_summary: projectData.project_typologies?.map((typology)=>({
        ...typology,
        price_range: typology.sale_price_from && typology.sale_price_to ? `${formatCurrency(typology.sale_price_from, typology.sale_currency)} - ${formatCurrency(typology.sale_price_to, typology.sale_currency)}` : 'Precio a consultar',
        area_range: typology.built_area ? `${typology.built_area} m²` : null,
        availability_status: typology.is_sold_out ? 'Agotado' : typology.available_units > 0 ? `${typology.available_units} disponibles` : 'Consultar disponibilidad'
      })) || [],
    developer_info: projectData.developers ? {
      ...projectData.developers,
      has_contact: !!(projectData.developers.email || projectData.developers.phone)
    } : null,
    project_statistics: {
      total_typologies: projectData.project_typologies?.length || 0,
      total_amenities: projectData.project_amenities?.length || 0,
      total_payment_plans: projectData.project_payment_plans?.length || 0,
      total_phases: projectData.project_phases?.length || 0,
      estimated_units: projectData.project_phases?.reduce((sum, phase)=>sum + (phase.total_units || 0), 0) || projectData.total_units || 0,
      available_units: projectData.project_phases?.reduce((sum, phase)=>sum + (phase.available_units || 0), 0) || projectData.available_units || 0
    },
    project_status: {
      current_phase: projectData.project_phases?.find((phase)=>phase.status === 'active') || projectData.project_phases?.find((phase)=>phase.completion_percentage < 100) || projectData.project_phases?.[0],
      overall_completion: calculateProjectCompletion(projectData.project_phases),
      construction_status: projectData.construction_status,
      sales_status: projectData.sales_status,
      is_pre_construction: projectData.construction_status === 'pre_construction',
      is_under_construction: projectData.construction_status === 'construction',
      is_completed: projectData.construction_status === 'completed'
    },
    payment_plans_formatted: projectData.project_payment_plans?.map((plan)=>({
        ...plan,
        reservation_formatted: plan.reservation_amount ? formatCurrency(plan.reservation_amount, plan.reservation_currency) : null,
        percentages_breakdown: {
          reservation: plan.separation_percentage || 0,
          construction: plan.construction_percentage || 0,
          delivery: plan.delivery_percentage || 0
        },
        total_percentage: (plan.separation_percentage || 0) + (plan.construction_percentage || 0) + (plan.delivery_percentage || 0)
      })) || []
  };
  console.log('✅ Proyecto enriquecido exitosamente');
  console.log('📊 Resumen final del proyecto:', {
    name: enrichedProject.name,
    has_developer: !!enrichedProject.developer_info,
    typologies: enrichedProject.project_statistics.total_typologies,
    amenities: enrichedProject.project_statistics.total_amenities,
    phases: enrichedProject.project_statistics.total_phases,
    payment_plans: enrichedProject.project_statistics.total_payment_plans
  });
  return enrichedProject;
}
// =====================================================
// RESTO DE FUNCIONES EXISTENTES (SIN CAMBIOS)
// =====================================================
// Funciones de galería de imágenes
async function getFullImageGalleryEnhanced(supabaseClient, propertyId) {
  try {
    console.log('📸 === PROCESANDO GALERÍA MEJORADA ===');
    console.log('📋 Property ID:', propertyId);
    const { data: property, error: propertyError } = await supabaseClient.from('properties').select('main_image_url, gallery_images_url').eq('id', propertyId).single();
    if (propertyError) {
      console.error('❌ Error obteniendo property data:', propertyError);
      return {
        main_image: '/images/placeholder-property.jpg',
        gallery_images: [],
        all_images: [
          '/images/placeholder-property.jpg'
        ]
      };
    }
    const { data: propertyImages, error: imagesError } = await supabaseClient.from('property_images').select('*').eq('property_id', propertyId).order('sort_order', {
      ascending: true
    });
    if (imagesError) {
      console.error('❌ Error obteniendo property_images:', imagesError);
    }
    let primaryImage = '/images/placeholder-property.jpg';
    if (propertyImages && propertyImages.length > 0) {
      const mainFromPropertyImages = propertyImages.find((img)=>img.is_main === true);
      if (mainFromPropertyImages?.url) {
        primaryImage = mainFromPropertyImages.url;
        console.log('✅ Imagen principal desde property_images:', primaryImage);
      } else if (propertyImages[0]?.url) {
        primaryImage = propertyImages[0].url;
        console.log('✅ Imagen principal desde primera property_image:', primaryImage);
      }
    }
    if (primaryImage === '/images/placeholder-property.jpg' && property?.main_image_url) {
      primaryImage = property.main_image_url;
      console.log('✅ Imagen principal desde main_image_url:', primaryImage);
    }
    const galleryUrls = new Set();
    if (propertyImages && propertyImages.length > 0) {
      propertyImages.forEach((img)=>{
        if (img.url && img.url !== primaryImage) {
          galleryUrls.add(img.url);
        }
      });
      console.log('📋 URLs agregadas desde property_images:', galleryUrls.size);
    }
    if (property?.gallery_images_url) {
      let urls = [];
      if (Array.isArray(property.gallery_images_url)) {
        urls = property.gallery_images_url.flatMap((url)=>{
          if (typeof url === 'string' && url.includes(',')) {
            return url.split(',').map((u)=>u.trim()).filter(Boolean);
          }
          return typeof url === 'string' ? url : '';
        }).filter(Boolean);
      } else if (typeof property.gallery_images_url === 'string') {
        urls = property.gallery_images_url.split(',').map((url)=>url.trim()).filter((url)=>url && url !== '');
      }
      urls.forEach((url)=>{
        if (url && url !== primaryImage) {
          galleryUrls.add(url);
        }
      });
      console.log('📋 URLs procesadas desde gallery_images_url:', urls.length, 'total en Set:', galleryUrls.size);
    }
    const galleryArray = Array.from(galleryUrls);
    const result = {
      main_image: primaryImage,
      gallery_images: galleryArray.map((url, index)=>({
          url,
          title: `Imagen ${index + 1}`,
          description: null,
          is_main: false,
          sort_order: index,
          source: 'processed'
        })),
      all_images: [
        primaryImage,
        ...galleryArray
      ]
    };
    console.log('✅ === GALERÍA PROCESADA EXITOSAMENTE ===');
    console.log('📊 Resumen:', {
      main_image: !!result.main_image,
      gallery_count: result.gallery_images.length,
      total_images: result.all_images.length,
      no_duplicates_guaranteed: true,
      main_image_in_gallery: galleryArray.includes(primaryImage)
    });
    return result;
  } catch (error) {
    console.error('❌ Error en getFullImageGalleryEnhanced:', error);
    return {
      main_image: '/images/placeholder-property.jpg',
      gallery_images: [],
      all_images: [
        '/images/placeholder-property.jpg'
      ]
    };
  }
}
// Funciones de agentes
async function getAgentByReferralCode(supabaseClient, referralCode) {
  if (!referralCode) return null;
  console.log('🎯 Buscando agente con código:', referralCode);
  try {
    let { data: agent, error } = await supabaseClient.from('users').select(`
        id, external_id, first_name, last_name, email, phone, 
        position, slug, biography, facebook_url, instagram_url, 
        twitter_url, linkedin_url, youtube_url,
        active, show_on_website, user_type
      `).eq('external_id', referralCode).single();
    if (agent) {
      console.log('✅ Agente encontrado por external_id');
      return agent;
    }
    ({ data: agent, error } = await supabaseClient.from('users').select(`
        id, external_id, first_name, last_name, email, phone, 
        position, slug, biography, facebook_url, instagram_url, 
        twitter_url, linkedin_url, youtube_url,
        active, show_on_website, user_type
      `).eq('slug', referralCode).single());
    if (agent) {
      console.log('✅ Agente encontrado por slug');
      return agent;
    }
    console.log('❌ No se encontró agente para código:', referralCode);
    return null;
  } catch (error) {
    console.error('❌ Error buscando agente de referido:', error);
    return null;
  }
}
async function getPropertyAgent(supabaseClient, agentId) {
  if (!agentId) return null;
  try {
    const { data: agent, error } = await supabaseClient.from('users').select(`
        id, external_id, first_name, last_name, email, phone, 
        position, slug, biography, facebook_url, instagram_url, 
        twitter_url, linkedin_url, youtube_url,
        active, show_on_website, user_type
      `).eq('id', agentId).single();
    if (error) {
      console.log('❌ Error obteniendo agente de propiedad:', error.message);
      return null;
    }
    return agent;
  } catch (error) {
    console.error('❌ Error crítico buscando agente de propiedad:', error);
    return null;
  }
}
function formatAgent(agent, isReferral = false) {
  if (!agent) return null;
  return {
    id: agent.id,
    name: `${agent.first_name || ''} ${agent.last_name || ''}`.trim(),
    email: agent.email,
    phone: agent.phone,
    position: agent.position || 'Asesor Inmobiliario',
    slug: agent.slug,
    biography: agent.biography,
    external_id: agent.external_id,
    social: {
      facebook: agent.facebook_url,
      instagram: agent.instagram_url,
      twitter: agent.twitter_url,
      linkedin: agent.linkedin_url,
      youtube: agent.youtube_url
    },
    is_referral_agent: isReferral,
    referral_code: isReferral ? agent.external_id || agent.slug || agent.id : null,
    active: agent.active,
    show_on_website: agent.show_on_website,
    profile_image: agent.profile_image || '/images/default-agent.jpg',
    rating: agent.rating || 4.8,
    user_type: agent.user_type
  };
}
function getClicDefaultAgent() {
  return {
    name: 'CLIC Inmobiliaria',
    email: 'info@clicinmobiliaria.com',
    phone: '+1-809-555-0100',
    position: 'Equipo Comercial',
    slug: 'clic-inmobiliaria',
    biography: 'Somos el equipo comercial de CLIC Inmobiliaria, especialistas en propiedades premium en República Dominicana.',
    external_id: 'CLIC-DEFAULT',
    social: {
      facebook: 'https://facebook.com/clicinmobiliaria',
      instagram: 'https://instagram.com/clicinmobiliaria',
      twitter: null,
      linkedin: 'https://linkedin.com/company/clicinmobiliaria',
      youtube: 'https://youtube.com/@clicinmobiliaria'
    },
    is_referral_agent: false,
    referral_code: null,
    active: true,
    show_on_website: true,
    profile_image: '/images/clic-logo-agent.jpg',
    rating: 4.9,
    is_default_clic: true
  };
}
async function assignPropertyAgent(supabaseClient, property, referralAgent, referralCode) {
  let finalAgent = null;
  let agentSource = 'default_clic';
  console.log('🔄 Asignando agente:', {
    hasReferralAgent: !!referralAgent,
    referralAgentActive: referralAgent?.active,
    referralAgentShowOnWebsite: referralAgent?.show_on_website,
    propertyAgentId: property.agent_id
  });
  if (referralAgent && referralAgent.active === true && referralAgent.show_on_website === true) {
    console.log('✅ Usando agente de referido');
    finalAgent = formatAgent(referralAgent, true);
    agentSource = 'referral';
  } else if (property.agent_id) {
    console.log('🔄 Buscando agente de propiedad');
    const propertyAgent = await getPropertyAgent(supabaseClient, property.agent_id);
    if (propertyAgent && propertyAgent.active === true && propertyAgent.show_on_website === true) {
      console.log('✅ Usando agente de propiedad');
      finalAgent = formatAgent(propertyAgent, false);
      agentSource = 'property';
    } else {
      console.log('⚠️ Agente de propiedad no cumple condiciones - usando CLIC por defecto');
      finalAgent = getClicDefaultAgent();
      agentSource = 'default_clic';
    }
  } else {
    console.log('🏢 Usando agente CLIC por defecto');
    finalAgent = getClicDefaultAgent();
    agentSource = 'default_clic';
  }
  console.log('📋 === RESULTADO ASIGNACIÓN AGENTE ===');
  console.log('🎯 Agente final:', {
    source: agentSource,
    name: finalAgent?.name,
    isReferral: agentSource === 'referral',
    isProperty: agentSource === 'property',
    isDefault: agentSource === 'default_clic'
  });
  return {
    finalAgent,
    agentSource
  };
}
// =====================================================
// FUNCIÓN DE CONTENIDO GENERAL ACTUALIZADA
// =====================================================
async function getDefaultRelatedContent(supabaseClient) {
  try {
    const [articles, videos, faqs, testimonials, seoContent] = await Promise.all([
      // ✅ CORREGIDO - Removido reading_time que no existe
      supabaseClient.from('articles').select(`
        id, title, slug, excerpt, content, featured_image,
        published_at, created_at, updated_at,
        meta_title, meta_description
      `).eq('status', 'published').order('published_at', {
        ascending: false
      }).limit(5),
      supabaseClient.from('videos').select(`
        id, title, description, video_slug, thumbnail, video_id, 
        video_platform, duration, views, category, featured,
        meta_title, meta_description, status, published_at, 
        created_at, updated_at, subtitle
      `).eq('status', 'published').order('published_at', {
        ascending: false
      }).limit(4),
      supabaseClient.from('faqs').select(`
        id, question, answer, sort_order, category,
        created_at, updated_at, status
      `).eq('status', 'published').order('sort_order').limit(6),
      supabaseClient.from('testimonials').select(`
        id, slug, title, excerpt, full_testimonial, rating,
        client_name, client_avatar, client_location, client_verified,
        client_profession, featured_image, views, featured,
        meta_title, meta_description, status, published_at, created_at
      `).eq('status', 'published').order('published_at', {
        ascending: false
      }).limit(3),
      supabaseClient.from('seo_content').select(`
        id, title, description, h1_title, h2_subtitle, 
        seo_content, content_type, identifier,
        location_context, property_type_context, operation_context,
        views, performance_score, version, status,
        created_at, updated_at
      `).eq('status', 'published').order('created_at', {
        ascending: false
      }).limit(3)
    ]);
    return {
      articles: articles.data || [],
      videos: (videos.data || []).map((video)=>({
          ...video,
          formatted_duration: formatDuration(video.duration),
          youtube_url: video.video_platform === 'youtube' && video.video_id ? `https://www.youtube.com/watch?v=${video.video_id}` : null
        })),
      testimonials: (testimonials.data || []).map((testimonial)=>({
          ...testimonial,
          content: testimonial.full_testimonial,
          client_title: testimonial.client_profession
        })),
      faqs: faqs.data || [],
      seo_content: (seoContent.data || []).map((content)=>({
          ...content,
          content: content.seo_content,
          page_url: content.identifier
        })),
      zone_testimonials: [],
      zone_videos: [],
      zone_faqs: [],
      zone_articles: [],
      featured_content: [],
      success_stories: []
    };
  } catch (error) {
    console.error('❌ Error obteniendo contenido por defecto:', error);
    return {
      articles: [],
      videos: [],
      testimonials: [],
      faqs: [],
      seo_content: [],
      zone_testimonials: [],
      zone_videos: [],
      zone_faqs: [],
      zone_articles: [],
      featured_content: [],
      success_stories: []
    };
  }
}
// =====================================================
// RESTO DE FUNCIONES (búsqueda, tags, formateo, etc.)
// [TODAS LAS FUNCIONES EXISTENTES SIN CAMBIOS]
// =====================================================
// Funciones de búsqueda y tags
async function searchPropertyBySlugUrl(supabaseClient, searchPath) {
  console.log('🔍 === BÚSQUEDA POR SLUG_URL ===');
  console.log('📋 Buscando:', searchPath);
  const selectQuery = `
    id, code, name, private_name, description, agent_id, slug_url,
    sale_price, sale_currency, rental_price, rental_currency,
    temp_rental_price, temp_rental_currency, furnished_rental_price, furnished_rental_currency,
    bedrooms, bathrooms, parking_spots, built_area, land_area,
    main_image_url, gallery_images_url, property_status, is_project, availability,
    delivery_date, release_date, created_at, updated_at, project_detail_id,
    category_id, city_id, sector_id,
    property_categories(id, name, description),
    cities(id, name, provinces(id, name, countries(id, name))),
    sectors(id, name),
    property_images(id, url, title, description, is_main, sort_order),
    property_amenities(id, amenity_id, value, amenities(id, name, icon, category))
  `;
  try {
    const searchVariants = [
      searchPath,
      `/${searchPath}`,
      searchPath.replace(/^\//, ''),
      `/${searchPath.replace(/^\//, '')}`
    ];
    console.log('🔍 Probando estas variantes:', searchVariants);
    for (const variant of searchVariants){
      console.log(`🎯 Probando exacta: "${variant}"`);
      const { data: property, error } = await supabaseClient.from('properties').select(selectQuery).eq('slug_url', variant).eq('availability', 1).eq('property_status', 'Publicada').limit(1).single();
      if (!error && property) {
        console.log(`✅ ¡ENCONTRADA! slug_url exacto: "${variant}"`);
        console.log('📋 Propiedad encontrada:', {
          id: property.id,
          name: property.name,
          slug_url: property.slug_url
        });
        return {
          found: true,
          property: property,
          searchMethod: 'exact_slug',
          matchedVariant: variant
        };
      } else if (error && error.code !== 'PGRST116') {
        console.log(`❌ Error en "${variant}":`, error.message);
      } else {
        console.log(`❌ No encontrada exacta: "${variant}"`);
      }
    }
    console.log('❌ No encontrada con búsqueda exacta - NO es propiedad individual');
    return {
      found: false,
      property: null,
      searchPath: searchPath,
      message: 'No encontrada con búsqueda exacta en slug_url'
    };
  } catch (error) {
    console.error('❌ Error crítico en búsqueda:', error);
    return {
      found: false,
      property: null,
      error: error.message
    };
  }
}
function parseUrlToSlugs(pathname) {
  const systemRoutes = [
    '/property-search',
    '/api',
    '/functions',
    '/_app',
    '/admin'
  ];
  if (systemRoutes.some((route)=>pathname.startsWith(route))) {
    return [];
  }
  const segments = pathname.replace(/^\//, '').split('/').filter((segment)=>segment.length > 0).map((segment)=>segment.toLowerCase().trim());
  const lastSegment = segments[segments.length - 1];
  if (lastSegment && /^.+-\d+$/.test(lastSegment)) {
    return segments.slice(0, -1);
  }
  return segments;
}
async function findTagsBySlug(supabaseClient, slugs) {
  if (slugs.length === 0) return [];
  const { data: tags, error } = await supabaseClient.from('tags').select('id, name, slug, category').in('slug', slugs);
  if (error) {
    console.error('Error buscando tags:', error);
    return [];
  }
  return tags || [];
}
async function searchPropertiesByTags(supabaseClient, tagIds, page = 1, limit = 50) {
  const offset = (page - 1) * limit;
  if (tagIds.length === 0) {
    return {
      properties: [],
      totalCount: 0
    };
  }
  try {
    const { data: propertyIds, error: rpcError } = await supabaseClient.rpc('get_properties_with_all_tags', {
      tag_ids: tagIds
    });
    if (!rpcError && propertyIds && propertyIds.length > 0) {
      const totalCount = propertyIds.length;
      const limitedPropertyIds = propertyIds.slice(offset, offset + limit);
      const { data: properties, error: propertiesError } = await supabaseClient.from('properties').select(`
          id, code, name, private_name, description, agent_id,
          sale_price, sale_currency, rental_price, rental_currency,
          temp_rental_price, temp_rental_currency,
          furnished_rental_price, furnished_rental_currency,
          bedrooms, bathrooms, parking_spots, built_area, land_area,
          main_image_url, gallery_images_url, property_status, is_project,
          delivery_date, release_date, created_at, updated_at,
          project_detail_id,
          property_categories(name, description),
          cities(name, provinces(name, countries(name))),
          sectors(name),
          property_images(url, title, description, is_main, sort_order),
          property_amenities(amenity_id, value, amenities(name, icon, category))
        `).in('id', limitedPropertyIds).eq('availability', 1).eq('property_status', 'Publicada');
      if (!propertiesError && properties) {
        return {
          properties: properties,
          totalCount
        };
      }
    }
    console.log('🔄 Usando método fallback con content_tags');
    const { data: contentTags, error: contentTagsError } = await supabaseClient.from('content_tags').select('content_id, tag_id').eq('content_type', 'property').in('tag_id', tagIds);
    if (contentTagsError || !contentTags) {
      return {
        properties: [],
        totalCount: 0
      };
    }
    const tagCountByProperty = {};
    contentTags.forEach((ct)=>{
      tagCountByProperty[ct.content_id] = (tagCountByProperty[ct.content_id] || 0) + 1;
    });
    const requiredTagCount = tagIds.length;
    const validPropertyIds = Object.keys(tagCountByProperty).filter((propertyId)=>tagCountByProperty[propertyId] === requiredTagCount);
    if (validPropertyIds.length === 0) {
      return {
        properties: [],
        totalCount: 0
      };
    }
    const totalCount = validPropertyIds.length;
    const limitedPropertyIds = validPropertyIds.slice(offset, offset + limit);
    const { data: properties, error: propertiesError } = await supabaseClient.from('properties').select(`
        id, code, name, private_name, description, agent_id,
        sale_price, sale_currency, rental_price, rental_currency,
        temp_rental_price, temp_rental_currency,
        furnished_rental_price, furnished_rental_currency,
        bedrooms, bathrooms, parking_spots, built_area, land_area,
        main_image_url, gallery_images_url, property_status, is_project,
        delivery_date, release_date, created_at, updated_at,
        project_detail_id,
        property_categories(name, description),
        cities(name, provinces(name, countries(name))),
        sectors(name),
        property_images(url, title, description, is_main, sort_order),
        property_amenities(amenity_id, value, amenities(name, icon, category))
      `).in('id', limitedPropertyIds).eq('availability', 1).eq('property_status', 'Publicada');
    if (propertiesError) {
      console.error('❌ Error obteniendo propiedades:', propertiesError);
      return {
        properties: [],
        totalCount: 0
      };
    }
    return {
      properties: properties || [],
      totalCount
    };
  } catch (error) {
    console.error('❌ Error en searchPropertiesByTags:', error);
    return {
      properties: [],
      totalCount: 0
    };
  }
}
async function getPropertyTags(supabaseClient, propertyId) {
  try {
    const { data: contentTags, error } = await supabaseClient.from('content_tags').select(`
        tag_id,
        weight,
        tags!inner(id, name, slug, category, display_name)
      `).eq('content_id', propertyId).eq('content_type', 'property').order('weight', {
      ascending: false
    });
    if (error) {
      console.error('❌ Error obteniendo tags de propiedad:', error);
      return [];
    }
    const tags = (contentTags || []).filter((ct)=>ct.tags).map((ct)=>({
        ...ct.tags,
        weight: ct.weight || 1
      }));
    console.log('✅ Tags de propiedad obtenidos:', {
      total: tags.length,
      byCategory: tags.reduce((acc, tag)=>{
        acc[tag.category] = (acc[tag.category] || 0) + 1;
        return acc;
      }, {}),
      topWeights: tags.slice(0, 5).map((t)=>`${t.category}:${t.name}(${t.weight})`)
    });
    return tags;
  } catch (error) {
    console.error('❌ Error en getPropertyTags:', error);
    return [];
  }
}
// Funciones de formateo
function formatPropertyForDetail(property, fullImageGallery, locationData, finalAgent) {
  const mainPrice = property.sale_price || property.rental_price || property.temp_rental_price || property.furnished_rental_price;
  const mainCurrency = property.sale_currency || property.rental_currency || property.temp_rental_currency || property.furnished_rental_currency || 'USD';
  let formattedPrice = 'Precio a consultar';
  if (property.sale_price) {
    formattedPrice = formatCurrency(property.sale_price, property.sale_currency);
  } else if (property.rental_price) {
    formattedPrice = formatCurrency(property.rental_price, property.rental_currency) + '/mes';
  } else if (property.temp_rental_price) {
    formattedPrice = formatCurrency(property.temp_rental_price, property.temp_rental_currency) + '/noche';
  } else if (property.furnished_rental_price) {
    formattedPrice = formatCurrency(property.furnished_rental_price, property.furnished_rental_currency) + '/mes amueblado';
  }
  return {
    id: property.id,
    code: property.code,
    title: property.name,
    private_name: property.private_name,
    description: property.description,
    is_project: property.is_project,
    sale_price: property.sale_price,
    sale_currency: property.sale_currency || 'USD',
    rental_price: property.rental_price,
    rental_currency: property.rental_currency || 'USD',
    temp_rental_price: property.temp_rental_price,
    temp_rental_currency: property.temp_rental_currency || 'USD',
    furnished_rental_price: property.furnished_rental_price,
    furnished_rental_currency: property.furnished_rental_currency || 'USD',
    main_price: mainPrice,
    main_currency: mainCurrency,
    formatted_price: formattedPrice,
    bedrooms: property.bedrooms,
    bathrooms: property.bathrooms,
    parking_spots: property.parking_spots,
    built_area: property.built_area,
    land_area: property.land_area,
    property_status: property.property_status,
    availability: property.availability,
    delivery_date: property.delivery_date,
    location: locationData,
    main_image_url: fullImageGallery.main_image,
    gallery_images: fullImageGallery.gallery_images.map((img)=>img.url),
    category: property.property_categories,
    amenities: property.property_amenities || [],
    agent: finalAgent,
    slug_url: property.slug_url,
    created_at: property.created_at,
    updated_at: property.updated_at
  };
}
function formatPropertyForListing(property) {
  let price = 'Precio a consultar';
  if (property.sale_price) {
    price = formatCurrency(property.sale_price, property.sale_currency);
  } else if (property.rental_price) {
    price = formatCurrency(property.rental_price, property.rental_currency);
  } else if (property.temp_rental_price) {
    price = formatCurrency(property.temp_rental_price, property.temp_rental_currency);
  }
  let mainImage = property.main_image_url;
  if (!mainImage && property.gallery_images_url) {
    if (Array.isArray(property.gallery_images_url)) {
      mainImage = property.gallery_images_url[0];
    } else if (typeof property.gallery_images_url === 'string') {
      mainImage = property.gallery_images_url.split(',')[0]?.trim();
    }
  }
  return {
    id: property.id,
    title: property.name,
    price: price,
    bedrooms: property.bedrooms,
    bathrooms: property.bathrooms,
    area: property.built_area || property.land_area,
    image: mainImage || '/images/placeholder-property.jpg',
    location: formatLocation(property),
    type: property.property_categories?.name,
    url: generatePropertyUrl(property),
    is_project: property.is_project,
    parking_spots: property.parking_spots,
    agent: null
  };
}
function formatLocation(property) {
  const parts = [
    property.sectors?.name,
    property.cities?.name
  ].filter(Boolean);
  return parts.length > 0 ? parts.join(', ') : 'Ubicación no especificada';
}
function generatePropertyUrl(property) {
  return property.slug_url || `/propiedad/${property.id}`;
}
// Funciones auxiliares restantes (ubicación, mercado, propiedades similares, etc.)
async function getEnrichedLocationData(supabaseClient, cityId, sectorId) {
  console.log('📍 Obteniendo datos de ubicación enriquecidos...');
  try {
    const { data: locationData } = await supabaseClient.from('sectors').select(`
        name,
        cities(
          name,
          provinces(
            name,
            countries(name)
          )
        )
      `).eq('id', sectorId).single();
    const enhancedLocation = {
      coordinates: {
        lat: 18.4682,
        lng: -69.9279
      },
      full_address: formatFullLocationAddress(locationData),
      nearby_services: await getNearbyServices(supabaseClient, sectorId),
      transportation: await getTransportationInfo(supabaseClient, sectorId),
      zone_highlights: [
        'Zona de alto crecimiento urbano',
        'Excelente conectividad vial',
        'Servicios médicos y educativos cercanos'
      ],
      demographics: {
        population: 245000,
        median_age: 32,
        household_income: 'Media-Alta',
        education_level: 'Universitaria',
        family_composition: 'Familias jóvenes',
        growth_rate: 8.5
      },
      development_projects: []
    };
    console.log('✅ Datos de ubicación enriquecidos obtenidos');
    return enhancedLocation;
  } catch (error) {
    console.error('❌ Error obteniendo datos de ubicación:', error);
    return getDefaultLocationData();
  }
}
async function getNearbyServices(supabaseClient, sectorId) {
  return [
    {
      category: 'hospital',
      name: 'Hospital Regional Dr. Marcelino Vélez Santana',
      distance: '2.5 km',
      rating: 4.2,
      address: 'Ave. Independencia'
    },
    {
      category: 'school',
      name: 'Colegio Loyola',
      distance: '1.8 km',
      rating: 4.6,
      address: 'Ave. Máximo Gómez'
    },
    {
      category: 'mall',
      name: 'Plaza Central',
      distance: '3.1 km',
      rating: 4.4,
      address: 'Ave. 27 de Febrero'
    }
  ];
}
async function getTransportationInfo(supabaseClient, sectorId) {
  return {
    metro_stations: [],
    bus_routes: [
      {
        route: 'B1',
        description: 'Hacia Centro Olímpico'
      },
      {
        route: 'B5',
        description: 'Hacia Zona Colonial'
      }
    ],
    main_roads: [
      'Autopista Duarte',
      'Ave. Independencia'
    ],
    taxi_apps: [
      'Uber',
      'Cabify',
      'InDriver'
    ],
    public_transport_score: 7.5
  };
}
function formatFullLocationAddress(locationData) {
  if (!locationData) return 'República Dominicana';
  const parts = [
    locationData.name,
    locationData.cities?.name,
    locationData.cities?.provinces?.name,
    locationData.cities?.provinces?.countries?.name
  ].filter(Boolean);
  return parts.join(', ');
}
function getDefaultLocationData() {
  return {
    coordinates: {
      lat: 18.4682,
      lng: -69.9279
    },
    full_address: 'República Dominicana',
    nearby_services: [],
    transportation: {
      metro_stations: [],
      bus_routes: [],
      main_roads: []
    },
    zone_highlights: [
      'Ubicación privilegiada'
    ],
    demographics: {},
    development_projects: []
  };
}
async function getSmartSimilarProperties(supabaseClient, propertyTags, excludeId) {
  console.log('🏠 === BUSCANDO PROPIEDADES SIMILARES INTELIGENTES ===');
  console.log('📋 Exclude ID:', excludeId);
  console.log('📋 Tags disponibles:', propertyTags?.length || 0);
  if (!propertyTags || propertyTags.length === 0) {
    console.log('⚠️ No hay tags de la propiedad, buscando propiedades aleatorias');
    return await getFallbackSimilarProperties(supabaseClient, excludeId);
  }
  try {
    const tagIds = propertyTags.map((t)=>t.id);
    console.log('🔍 Buscando propiedades que tengan estos tag IDs:', tagIds);
    const { data: propertyMatches, error } = await supabaseClient.from('content_tags').select(`
        content_id,
        tag_id,
        weight,
        tags(id, name, category)
      `).eq('content_type', 'property').in('tag_id', tagIds).neq('content_id', excludeId);
    if (error || !propertyMatches) {
      console.error('❌ Error buscando propiedades similares:', error);
      return await getFallbackSimilarProperties(supabaseClient, excludeId);
    }
    console.log('📊 Property matches encontrados:', propertyMatches.length);
    const propertyScores = {};
    const categoryWeights = {
      'operacion': 5,
      'categoria': 4,
      'ciudad': 3,
      'sector': 3,
      'provincia': 2,
      'caracteristica': 1
    };
    propertyMatches.forEach((match)=>{
      const propertyId = match.content_id;
      const tagCategory = match.tags?.category || 'caracteristica';
      const categoryWeight = categoryWeights[tagCategory] || 1;
      const tagWeight = match.weight || 1;
      if (!propertyScores[propertyId]) {
        propertyScores[propertyId] = {
          property_id: propertyId,
          total_score: 0,
          matched_tags: 0,
          categories: new Set()
        };
      }
      propertyScores[propertyId].total_score += categoryWeight * tagWeight;
      propertyScores[propertyId].matched_tags += 1;
      propertyScores[propertyId].categories.add(tagCategory);
    });
    const validProperties = Object.values(propertyScores).filter((prop)=>prop.matched_tags >= 2).sort((a, b)=>b.total_score - a.total_score).slice(0, 6);
    if (validProperties.length === 0) {
      console.log('⚠️ No hay propiedades con suficientes coincidencias, bajando a 1 tag mínimo');
      const validPropertiesLowBar = Object.values(propertyScores).filter((prop)=>prop.matched_tags >= 1).sort((a, b)=>b.total_score - a.total_score).slice(0, 6);
      if (validPropertiesLowBar.length === 0) {
        return await getFallbackSimilarProperties(supabaseClient, excludeId);
      }
      const propertyIds = validPropertiesLowBar.map((p)=>p.property_id);
      return await getPropertiesDetails(supabaseClient, propertyIds);
    }
    console.log('📊 Propiedades similares encontradas:', {
      totalMatches: Object.keys(propertyScores).length,
      with2PlusMatches: validProperties.length,
      topScores: validProperties.slice(0, 3).map((p)=>`${p.matched_tags} tags, score: ${p.total_score}`)
    });
    const propertyIds = validProperties.map((p)=>p.property_id);
    return await getPropertiesDetails(supabaseClient, propertyIds);
  } catch (error) {
    console.error('❌ Error en getSmartSimilarProperties:', error);
    return await getFallbackSimilarProperties(supabaseClient, excludeId);
  }
}
async function getFallbackSimilarProperties(supabaseClient, excludeId) {
  console.log('🔄 Usando método fallback para propiedades similares');
  try {
    const { data: properties, error } = await supabaseClient.from('properties').select(`
        id, code, name, sale_price, rental_price, temp_rental_price,
        furnished_rental_price, sale_currency, rental_currency,
        bedrooms, bathrooms, parking_spots, built_area, land_area,
        main_image_url, gallery_images_url, is_project, slug_url,
        property_categories(name),
        cities(name, provinces(name)),
        sectors(name)
      `).neq('id', excludeId).eq('availability', 1).eq('property_status', 'Publicada').order('created_at', {
      ascending: false
    }).limit(6);
    if (error) {
      console.error('❌ Error en fallback properties:', error);
      return [];
    }
    console.log('✅ Propiedades fallback obtenidas:', properties?.length || 0);
    return (properties || []).map(formatSimilarProperty);
  } catch (error) {
    console.error('❌ Error en getFallbackSimilarProperties:', error);
    return [];
  }
}
async function getPropertiesDetails(supabaseClient, propertyIds) {
  if (!propertyIds || propertyIds.length === 0) return [];
  console.log('📋 Obteniendo detalles de', propertyIds.length, 'propiedades similares');
  try {
    const { data: properties, error } = await supabaseClient.from('properties').select(`
        id, code, name, sale_price, rental_price, temp_rental_price,
        furnished_rental_price, sale_currency, rental_currency,
        bedrooms, bathrooms, parking_spots, built_area, land_area,
        main_image_url, gallery_images_url, is_project, slug_url,
        property_categories(name),
        cities(name, provinces(name)),
        sectors(name)
      `).in('id', propertyIds).eq('availability', 1).eq('property_status', 'Publicada');
    if (error) {
      console.error('❌ Error obteniendo detalles de propiedades:', error);
      return [];
    }
    const orderedProperties = propertyIds.map((id)=>properties?.find((prop)=>prop.id === id)).filter(Boolean);
    console.log('✅ Propiedades similares obtenidas:', orderedProperties.length);
    return orderedProperties.map(formatSimilarProperty);
  } catch (error) {
    console.error('❌ Error en getPropertiesDetails:', error);
    return [];
  }
}
function formatSimilarProperty(property) {
  let price = 'Precio a consultar';
  if (property.sale_price) {
    price = formatCurrency(property.sale_price, property.sale_currency);
  } else if (property.rental_price) {
    price = formatCurrency(property.rental_price, property.rental_currency);
  } else if (property.temp_rental_price) {
    price = formatCurrency(property.temp_rental_price, property.temp_rental_currency);
  } else if (property.furnished_rental_price) {
    price = formatCurrency(property.furnished_rental_price, property.furnished_rental_currency);
  }
  let mainImage = property.main_image_url;
  if (!mainImage && property.gallery_images_url) {
    if (Array.isArray(property.gallery_images_url)) {
      mainImage = property.gallery_images_url[0];
    } else if (typeof property.gallery_images_url === 'string') {
      mainImage = property.gallery_images_url.split(',')[0]?.trim();
    }
  }
  return {
    id: property.id,
    title: property.name,
    price: price,
    bedrooms: property.bedrooms,
    bathrooms: property.bathrooms,
    area: property.built_area || property.land_area,
    image: mainImage || '/images/placeholder-property.jpg',
    location: formatLocation(property),
    type: property.property_categories?.name,
    url: property.slug_url || `/propiedad/${property.id}`,
    is_project: property.is_project,
    parking_spots: property.parking_spots
  };
}
async function getMarketInsights(supabaseClient, cityId, categoryId) {
  try {
    const { data: marketData } = await supabaseClient.from('properties').select('sale_price, rental_price, built_area, created_at').eq('city_id', cityId).eq('category_id', categoryId).eq('availability', 1).eq('property_status', 'Publicada').not('sale_price', 'is', null).order('created_at', {
      ascending: false
    }).limit(50);
    if (!marketData || marketData.length === 0) {
      return getDefaultMarketInsights();
    }
    const prices = marketData.map((p)=>p.sale_price).filter(Boolean);
    const avgPrice = prices.reduce((sum, price)=>sum + price, 0) / prices.length;
    return {
      average_price: Math.round(avgPrice),
      average_price_per_sqm: 1200,
      market_trend: 'growing',
      price_appreciation_annual: 8.5,
      rental_yield_estimate: 6.2,
      time_to_sell_days: 45,
      demand_level: 'high',
      inventory_level: 'medium',
      investment_outlook: 'excellent',
      market_activity: {
        total_listings: marketData.length,
        average_days_on_market: 45,
        new_listings_this_month: Math.floor(marketData.length * 0.15)
      }
    };
  } catch (error) {
    console.error('Error en getMarketInsights:', error);
    return getDefaultMarketInsights();
  }
}
function getDefaultMarketInsights() {
  return {
    average_price: 145000,
    average_price_per_sqm: 1200,
    market_trend: 'growing',
    price_appreciation_annual: 8.5,
    rental_yield_estimate: 6.2,
    time_to_sell_days: 45,
    demand_level: 'high',
    inventory_level: 'medium',
    investment_outlook: 'excellent',
    market_activity: {
      total_listings: 156,
      average_days_on_market: 45,
      new_listings_this_month: 23
    }
  };
}
async function handleSoldOrUnavailableProperty(supabaseClient, searchPath, referralAgent, referralCode, property) {
  return {
    type: 'property_sold_or_unavailable',
    status: 'sold_or_unavailable',
    message: 'Esta propiedad ya no está disponible'
  };
}
function generateStructuredData(property, projectDetails, locationData) {
  return {
    "@context": "https://schema.org",
    "@type": "RealEstateListing",
    "name": property.title,
    "description": property.description,
    "url": `https://clicinmobiliaria.com/propiedad/${property.id}`,
    "image": property.main_image_url,
    "price": {
      "@type": "PriceSpecification",
      "price": property.main_price,
      "priceCurrency": property.main_currency
    },
    "address": {
      "@type": "PostalAddress",
      "addressLocality": locationData.full_address,
      "addressCountry": "DO"
    },
    "numberOfRooms": property.bedrooms,
    "floorSize": {
      "@type": "QuantitativeValue",
      "value": property.built_area,
      "unitCode": "MTK"
    }
  };
}
function generateMetaDescription(property, projectDetails) {
  const location = property.location?.full_address || 'República Dominicana';
  const price = property.formatted_price || 'precio a consultar';
  return `${property.title} en ${location}. ${property.bedrooms || 'N/A'} hab, ${property.bathrooms || 'N/A'} baños, ${price}. ${property.description?.substring(0, 100) || ''}...`;
}
function generateBreadcrumbs(tags) {
  return [
    {
      name: 'Inicio',
      url: '/'
    },
    {
      name: 'Propiedades',
      url: '/propiedades'
    },
    {
      name: 'Santo Domingo Oeste',
      url: '/santo-domingo-oeste'
    },
    {
      name: 'Apartamentos',
      url: '/apartamento'
    },
    {
      name: 'Venta',
      url: '/comprar'
    },
    {
      name: 'Manoguayabo',
      url: '/manoguayabo'
    }
  ];
}
function generateOpenGraphData(property, gallery) {
  return {
    title: property.title,
    description: generateMetaDescription(property, null),
    image: property.main_image_url || gallery.main_image,
    type: 'website',
    url: `https://clicinmobiliaria.com/propiedad/${property.id}`
  };
}
function generatePropertyWidgets(property, similarProperties, basePrice) {
  return {};
}
function generateReferralInfo(referralAgent, referralCode, agentSource) {
  if (!referralAgent) return null;
  const wasUsed = agentSource === 'referral';
  const isEligible = referralAgent.active === true && referralAgent.show_on_website === true;
  return {
    agent_name: `${referralAgent.first_name} ${referralAgent.last_name}`,
    referral_code: referralCode,
    external_id: referralAgent.external_id,
    is_active: referralAgent.active,
    show_on_website: referralAgent.show_on_website,
    is_eligible: isEligible,
    was_used: wasUsed,
    reason_not_used: !wasUsed ? !referralAgent.active ? 'inactive' : !referralAgent.show_on_website ? 'not_visible_on_website' : 'unknown' : null
  };
}
function generateSeoTitle(tags, metadata) {
  if (tags.length === 0) return 'Propiedades en República Dominicana - CLIC';
  const categoryTag = tags.find((t)=>t.category === 'categoria');
  const locationTag = tags.find((t)=>t.category === 'ciudad' || t.category === 'provincia');
  const parts = [];
  if (categoryTag) parts.push(categoryTag.name);
  if (locationTag) parts.push(`en ${locationTag.name}`);
  const title = parts.length > 0 ? parts.join(' ') : 'Propiedades';
  return `${title} - CLIC`;
}
// =====================================================
// FUNCIONES PRINCIPALES DE MANEJO (ACTUALIZADAS)
// =====================================================
async function handleSinglePropertyPage(supabaseClient, property, referralAgent, referralCode, url, searchPath) {
  console.log('🏠 === PROCESANDO PÁGINA DE PROPIEDAD INDIVIDUAL (ACTUALIZADA) ===');
  try {
    const isAvailable = property.availability === 1 && property.property_status === 'Publicada';
    if (!isAvailable) {
      console.log('⚠️ Propiedad no disponible');
      return await handleSoldOrUnavailableProperty(supabaseClient, searchPath, referralAgent, referralCode, property);
    }
    console.log('🏷️ Obteniendo tags de la propiedad...');
    const propertyTags = await getPropertyTags(supabaseClient, property.id);
    console.log('👤 Procesando agente...');
    const { finalAgent, agentSource } = await assignPropertyAgent(supabaseClient, property, referralAgent, referralCode);
    console.log('⚡ Procesando datos en paralelo...');
    console.log('🏗️ DEBUG PROYECTO:', {
      is_project: property.is_project,
      project_detail_id: property.project_detail_id,
      property_id: property.id
    });
    // ✅ ACTUALIZADO: Incluir contenido específico
    const [locationData, projectDetails, fullImageGallery, specificContent, defaultContent, similarProperties, marketData] = await Promise.all([
      getEnrichedLocationData(supabaseClient, property.city_id, property.sector_id),
      property.is_project ? getCompleteProjectDetailsWithFallback(supabaseClient, property) : Promise.resolve(null),
      getFullImageGalleryEnhanced(supabaseClient, property.id),
      getPropertySpecificContent(supabaseClient, property.id),
      getDefaultRelatedContent(supabaseClient),
      getSmartSimilarProperties(supabaseClient, propertyTags, property.id),
      getMarketInsights(supabaseClient, property.city_id, property.category_id)
    ]);
    console.log('🏗️ PROJECT DETAILS RESULTADO:', {
      projectDetails: !!projectDetails,
      projectName: projectDetails?.name,
      projectId: projectDetails?.id
    });
    // ✅ ACTUALIZADO: Combinar contenido específico con general
    const enhancedContent = combineSpecificAndGeneralContent(specificContent, defaultContent);
    const formattedProperty = formatPropertyForDetail(property, fullImageGallery, locationData, finalAgent);
    const structuredData = generateStructuredData(formattedProperty, projectDetails, locationData);
    const widgetData = generatePropertyWidgets(formattedProperty, similarProperties, property.sale_price || property.rental_price || 120000);
    return {
      type: 'single_property_enhanced',
      property: formattedProperty,
      location: locationData,
      project: projectDetails,
      related_content: enhancedContent,
      similar_properties: similarProperties,
      widgets: widgetData,
      market: marketData,
      agent_info: {
        source: agentSource,
        is_referral: agentSource === 'referral',
        agent_found: !!finalAgent
      },
      referral_info: generateReferralInfo(referralAgent, referralCode, agentSource),
      seo: {
        title: `${formattedProperty.title} - ${formattedProperty.location.full_address} - CLIC`,
        description: generateMetaDescription(formattedProperty, projectDetails),
        canonical: url.pathname,
        structured_data: structuredData,
        breadcrumbs: generateBreadcrumbs([]),
        og_data: generateOpenGraphData(formattedProperty, fullImageGallery)
      },
      debug: {
        search_method: 'slug_url_enhanced',
        property_id: property.id,
        property_tags_found: propertyTags.length,
        agent_assignment: {
          source: agentSource,
          referral_provided: !!referralAgent,
          final_agent_name: finalAgent?.name
        },
        gallery_processing: {
          main_image: !!fullImageGallery.main_image,
          gallery_count: fullImageGallery.gallery_images.length,
          total_images: fullImageGallery.all_images.length
        },
        project_data: {
          is_project: property.is_project,
          project_details_found: !!projectDetails,
          project_amenities: projectDetails?.project_amenities?.length || 0
        },
        // ✅ NUEVO: Debug de contenido específico
        content_processing: {
          has_specific_content: !!specificContent?.has_specific_content,
          content_source: enhancedContent.content_source,
          specific_content_summary: enhancedContent.specific_content_summary || null
        }
      }
    };
  } catch (error) {
    console.error('❌ Error en handleSinglePropertyPage:', error);
    throw error;
  }
}
async function handlePropertyListing(supabaseClient, searchPath, referralAgent, referralCode, url, page, limit) {
  console.log('📋 === PROCESANDO LISTADO DE PROPIEDADES POR TAGS ===');
  try {
    const urlSlugs = parseUrlToSlugs(searchPath);
    console.log('🔍 URL slugs extraídos:', urlSlugs);
    const tags = await findTagsBySlug(supabaseClient, urlSlugs);
    const tagIds = tags.map((t)=>t.id);
    console.log('🏷️ Tags encontrados:', {
      slugs: urlSlugs,
      tags: tags.map((t)=>({
          slug: t.slug,
          category: t.category
        })),
      tagIds
    });
    const searchResults = await searchPropertiesByTags(supabaseClient, tagIds, page, limit);
    const formattedProperties = searchResults.properties.map((property)=>{
      const formatted = formatPropertyForListing(property);
      if (referralAgent && referralAgent.active === true && referralAgent.show_on_website === true) {
        formatted.agent = formatAgent(referralAgent, true);
        console.log(`✅ Agente de referido asignado a propiedad ${property.id}`);
      } else if (referralAgent) {
        console.log(`⚠️ Agente de referido NO asignado a propiedad ${property.id} - no cumple condiciones:`, {
          active: referralAgent.active,
          show_on_website: referralAgent.show_on_website
        });
      }
      return formatted;
    });
    const relatedContent = await getDefaultRelatedContent(supabaseClient);
    return {
      type: 'property_listing',
      data: formattedProperties,
      related_content: relatedContent,
      search: {
        url_path: url.pathname,
        original_slugs: urlSlugs,
        tags_found: tags,
        tags_used: tagIds
      },
      pagination: {
        page,
        limit,
        total: searchResults.totalCount,
        pages: Math.ceil(searchResults.totalCount / limit),
        has_next: page * limit < searchResults.totalCount,
        has_prev: page > 1
      },
      referral_info: generateReferralInfo(referralAgent, referralCode, 'referral'),
      seo: {
        title: generateSeoTitle(tags, {}),
        description: `Encuentra las mejores propiedades${tags.length > 0 ? ' en ' + tags.map((t)=>t.name).join(', ') : ''} con CLIC.`,
        canonical: url.pathname,
        tags: tags,
        breadcrumbs: generateBreadcrumbs(tags)
      },
      debug: {
        search_method: 'tags',
        url_slugs: urlSlugs,
        tags_found: tags.length,
        properties_found: formattedProperties.length
      }
    };
  } catch (error) {
    console.error('❌ Error en handlePropertyListing:', error);
    throw error;
  }
}
async function handleUnifiedPropertySearch(supabaseClient, searchPath, referralAgent, referralCode, url, page = 1, limit = 50) {
  console.log('🚀 === INICIANDO BÚSQUEDA UNIFICADA ===');
  console.log('📋 Path limpio recibido:', searchPath);
  console.log('🔍 PASO 1: Intentando búsqueda por slug_url...');
  const propertyResult = await searchPropertyBySlugUrl(supabaseClient, searchPath);
  if (propertyResult.found && propertyResult.property) {
    console.log('✅ ENCONTRADA COMO PROPIEDAD INDIVIDUAL');
    return await handleSinglePropertyPage(supabaseClient, propertyResult.property, referralAgent, referralCode, url, searchPath);
  }
  console.log('❌ No encontrada como propiedad individual');
  console.log('🔍 PASO 2: Procesando como listado por tags...');
  return await handlePropertyListing(supabaseClient, searchPath, referralAgent, referralCode, url, page, limit);
}
// =====================================================
// SERVIDOR PRINCIPAL
// =====================================================
serve(async (req)=>{
  if (req.method === 'OPTIONS') {
    return new Response('ok', {
      headers: corsHeaders
    });
  }
  try {
    const supabaseClient = createClient(Deno.env.get('SUPABASE_URL') ?? '', Deno.env.get('SUPABASE_ANON_KEY') ?? '');
    const url = new URL(req.url);
    const searchParams = url.searchParams;
    const referralCode = searchParams.get('ref');
    let referralAgent = null;
    console.log('🚀 === INICIANDO UNIFIED PROPERTY SEARCH (ACTUALIZADA) ===');
    console.log('📋 URL completa:', req.url);
    console.log('📋 Código de referido:', referralCode || 'NINGUNO');
    if (referralCode) {
      referralAgent = await getAgentByReferralCode(supabaseClient, referralCode);
      console.log('🎯 Agente de referido:', referralAgent ? `${referralAgent.first_name} ${referralAgent.last_name}` : 'NO ENCONTRADO');
    }
    let functionPath = url.pathname;
    const possiblePrefixes = [
      '/functions/v1/unified-property-search',
      '/functions/v1/property-search',
      '/functions/v1/pro-search',
      '/property-search',
      '/unified-property-search',
      '/pro-search'
    ];
    console.log('📋 Path original antes de limpiar:', functionPath);
    for (const prefix of possiblePrefixes){
      if (functionPath.startsWith(prefix)) {
        functionPath = functionPath.substring(prefix.length);
        console.log(`📋 Removido prefix "${prefix}", nuevo path:`, functionPath);
        break;
      }
    }
    if (functionPath.startsWith('/')) {
      functionPath = functionPath.substring(1);
    }
    if (!functionPath || functionPath === '') {
      const queryPath = searchParams.get('_path') || searchParams.get('path');
      if (queryPath) {
        functionPath = queryPath.startsWith('/') ? queryPath.substring(1) : queryPath;
        console.log('📋 Path desde query parameter:', functionPath);
      } else {
        functionPath = '';
      }
    }
    console.log('🔍 Path final para procesamiento (SIN PREFIJOS):', functionPath);
    if (functionPath.startsWith('pro-search/') || functionPath.startsWith('property-search/') || functionPath.startsWith('unified-property-search/')) {
      console.log('⚠️ Detectado resto de función en path, limpiando...');
      functionPath = functionPath.replace(/^(pro-search|property-search|unified-property-search)\//, '');
      console.log('🧹 Path después de limpieza adicional:', functionPath);
    }
    const page = parseInt(searchParams.get('page') || '1');
    const limit = Math.min(parseInt(searchParams.get('limit') || '50'), 100);
    const result = await handleUnifiedPropertySearch(supabaseClient, functionPath, referralAgent, referralCode, url, page, limit);
    console.log('✅ === UNIFIED PROPERTY SEARCH COMPLETADO (ACTUALIZADA) ===');
    console.log('📊 Tipo de resultado:', result.type);
    return new Response(JSON.stringify(result), {
      headers: {
        ...corsHeaders,
        'Content-Type': 'application/json'
      }
    });
  } catch (error) {
    console.error('❌ Error crítico en unified-property-search:', error);
    return new Response(JSON.stringify({
      error: 'Internal server error',
      message: error.message,
      timestamp: new Date().toISOString(),
      stack: Deno.env.get('ENVIRONMENT') === 'development' ? error.stack : undefined
    }), {
      status: 500,
      headers: {
        ...corsHeaders,
        'Content-Type': 'application/json'
      }
    });
  }
});
