// src/data/hybridProvider.ts - VERSIÓN CORREGIDA PARA ASTRO
// =====================================================
// PROVIDER COMPLETAMENTE CORREGIDO Y COMPATIBLE
// =====================================================

const SUPABASE_URL = 'https://pacewqgypevfgjmdsorz.supabase.co';
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InBhY2V3cWd5cGV2ZmdqbWRzb3J6Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDg2NjU4OTksImV4cCI6MjA2NDI0MTg5OX0.Qlg-UVy-sikr76GxYmTcfCz1EnAqPHxvFeLrdqnjuWs';

// =====================================================
// FUNCIÓN PRINCIPAL CON LIMPIEZA DE URLs
// =====================================================

async function getUnifiedData(segments: string[], searchParams?: URLSearchParams) {
  console.log('🔄 Calling Unified Edge Function');
  console.log('Original segments:', segments);
  
  try {
    // Limpiar segmentos - remover duplicados de "comprar"
    const cleanedSegments = cleanUrlSegments(segments);
    console.log('Cleaned segments:', cleanedSegments);
    
    const referralCode = searchParams?.get('ref');
    const page = searchParams?.get('page') || '1';
    const limit = searchParams?.get('limit') || '30';
    
    // Construir URL de la Edge Function
    const apiPath = cleanedSegments.length > 0 ? `/${cleanedSegments.join('/')}` : '/';
    let apiUrl = `${SUPABASE_URL}/functions/v1/busqueda${apiPath}`;
    
    // Agregar parámetros
    const params = new URLSearchParams();
    if (referralCode) params.set('ref', referralCode);
    if (page !== '1') params.set('page', page);
    if (limit !== '30') params.set('limit', limit);
    
    if (params.toString()) {
      apiUrl += `?${params.toString()}`;
    }
    
    console.log('Final API URL:', apiUrl);
    
    const response = await fetch(apiUrl, {
      headers: {
        'Authorization': `Bearer ${SUPABASE_ANON_KEY}`,
        'Content-Type': 'application/json'
      }
    });
    
    if (!response.ok) {
      throw new Error(`API Error: ${response.status}`);
    }
    
    return await response.json();
    
  } catch (error) {
    console.error('Error calling edge function:', error);
    throw error;
  }
}

// =====================================================
// LIMPIEZA AVANZADA DE URLs
// =====================================================

function cleanUrlSegments(segments: string[]): string[] {
  if (!segments || segments.length === 0) return [];
  
  let cleaned = segments
    .filter(segment => segment && segment.trim().length > 0)
    .map(segment => {
      // Remover IDs del final (-123)
      const withoutId = segment.replace(/-\d+$/, '');
      return withoutId || segment;
    });

  // Remover duplicados de "comprar" y otras palabras repetidas
  const seen = new Set();
  const duplicateWords = ['comprar', 'venta', 'alquilar', 'apartamento', 'casa'];
  
  cleaned = cleaned.filter(segment => {
    const segmentLower = segment.toLowerCase();
    
    // Si es una palabra que puede duplicarse
    if (duplicateWords.includes(segmentLower)) {
      if (seen.has(segmentLower)) {
        return false; // Skip duplicado
      }
      seen.add(segmentLower);
    }
    
    return true;
  });
  
  return cleaned;
}

// =====================================================
// SINGLE PROPERTY RESPONSE COMPLETO
// =====================================================

async function getSingleProperty(segments: string[], searchParams?: URLSearchParams) {
  try {
    const apiData = await getUnifiedData(segments, searchParams);
    
    if (apiData.type === 'single-property' || apiData.type === 'single-property-project') {
      return formatSinglePropertyResponse(apiData);
    }
    
    if (!apiData.available && apiData.property) {
      return {
        type: 'property-sold',
        message: apiData.message || 'Propiedad no disponible',
        alternatives: []
      };
    }
    
    return null;
    
  } catch (error) {
    console.error('Error getting single property:', error);
    return null;
  }
}

// =====================================================
// PROPERTY LIST RESPONSE COMPLETO
// =====================================================

async function getPropertyList(segments: string[], searchParams?: URLSearchParams) {
  try {
    const apiData = await getUnifiedData(segments, searchParams);
    
    if (apiData.type === 'property-list') {
      return formatPropertyListResponse(apiData);
    }
    
    return getEmptyResponse();
    
  } catch (error) {
    console.error('Error getting property list:', error);
    return getEmptyResponse();
  }
}

// =====================================================
// FORMATEO COMPLETO DE SINGLE PROPERTY
// =====================================================

function formatSinglePropertyResponse(apiData: any) {
  const property = apiData.property;
  const pricing = property.pricing_unified || {};
  const images = property.images_unified || [];
  
  return {
    type: 'property',
    
    // Datos principales usando pricing_unified e images_unified
    property: {
      id: property.id,
      title: property.name || '',
      subtitle: property.description?.substring(0, 100) + '...' || '',
      location: formatLocation(property),
      price: pricing.display_price?.formatted || 'Precio a consultar',
      reservation: 'US$1,000',
      reference: property.code || property.id,
      
      // Especificaciones
      bedrooms: property.bedrooms || 0,
      bathrooms: property.bathrooms || 0,
      parking_spots: property.parking_spots || 0,
      built_area: property.built_area || 0,
      land_area: property.land_area || 0,
      
      // Estado
      is_project: property.is_project || false,
      property_status: property.property_status,
      delivery_date: property.delivery_date,
      
      // Categoría y tipo
      category: property.property_categories?.name || 'Apartamento',
      operation_type: pricing.operation_type || 'sale',
      
      // URLs
      slug_url: property.slug_url,
      
      // Descripción completa
      description: property.description || ''
    },
    
    // Imágenes usando images_unified (CORREGIDO)
    images: formatImagesArray(images),
    mainImage: getMainImage(images),
    
    // Precios unificados completos
    pricing: {
      main: pricing.display_price || null,
      sale: pricing.sale || null,
      rental: pricing.rental || null,
      temp_rental: pricing.temp_rental || null,
      furnished_rental: pricing.furnished_rental || null,
      all_prices: pricing // Toda la información de precios
    },
    
    // Agente
    agent: formatAgent(apiData.agent || apiData.referralAgent),
    
    // Proyecto COMPLETO (CORREGIDO)
    project: apiData.projectDetails ? formatProjectComplete(apiData.projectDetails) : null,
    hasProject: !!apiData.projectDetails,
    
    // Ubicación con Google Places (CORREGIDO)
    location: {
      coordinates: extractCoordinates(property),
      address: formatLocation(property),
      sector: property.sectors?.name,
      city: property.cities?.name,
      province: property.cities?.provinces?.name,
      googlePlaces: extractGooglePlacesComplete(apiData.seo)
    },
    
    // Amenidades
    amenities: formatAmenities(property.property_amenities || []),
    
    // Contenido relacionado COMPLETO (CORREGIDO)
    content: {
      articles: apiData.relatedContent?.articles || [],
      videos: apiData.relatedContent?.videos || [],
      testimonials: apiData.relatedContent?.testimonials || [],
      faqs: apiData.relatedContent?.faqs || [],
      hasSpecificContent: !!(apiData.relatedContent?.has_specific_content)
    },
    
    // SEO
    seo: {
      title: apiData.seo?.title || property.name,
      description: apiData.seo?.description || property.description?.substring(0, 160),
      keywords: apiData.seo?.keywords || [],
      og: apiData.seo?.og || {},
      structuredData: apiData.seo?.structured_data || {}
    },
    
    // Breadcrumbs CORREGIDOS (acción/tipo/ubicación/sector)
    breadcrumbs: generateCorrectBreadcrumbs(property, 'property'),
    
    // Meta información
    meta: {
      timestamp: new Date().toISOString(),
      hasProject: !!apiData.projectDetails,
      hasAgent: !!(apiData.agent || apiData.referralAgent),
      imagesCount: images.length,
      googlePlacesEnabled: !!(apiData.seo?.places_enrichment),
      debug: apiData.debug || {}
    }
  };
}

// =====================================================
// FORMATEO COMPLETO DE PROPERTY LIST
// =====================================================

function formatPropertyListResponse(apiData: any) {
  const searchResults = apiData.searchResults || {};
  const properties = searchResults.properties || [];
  const pagination = searchResults.pagination || {};
  
  return {
    type: 'property-list',
    
    // Propiedades con datos unificados
    properties: properties.map(formatPropertyCard),
    
    // Paginación COMPLETA
    pagination: {
      currentPage: pagination.currentPage || 1,
      totalCount: pagination.totalCount || 0,
      itemsPerPage: pagination.itemsPerPage || 30,
      totalPages: pagination.totalPages || 1,
      hasMore: pagination.hasMore || false
    },
    
    // Información de búsqueda
    search: {
      tags: searchResults.tags || [],
      location: extractLocationFromTags(searchResults.tags),
      propertyType: extractPropertyTypeFromTags(searchResults.tags),
      operation: extractOperationFromTags(searchResults.tags)
    },
    
    // Google Places COMPLETO
    locationData: extractGooglePlacesComplete(apiData.seo),
    
    // SEO
    seo: {
      title: apiData.seo?.title || 'Propiedades - CLIC Inmobiliaria',
      description: apiData.seo?.description || '',
      h1: apiData.seo?.h1 || ''
    },
    
    // Contenido SEO enriquecido
    content: {
      intro: apiData.seoContent?.intro_text || '',
      benefits: apiData.seoContent?.benefits || [],
      nearbyServices: apiData.seoContent?.nearby_amenities || [],
      faqs: apiData.seoContent?.faq_optimized || []
    },
    
    // Breadcrumbs CORREGIDOS
    breadcrumbs: generateCorrectBreadcrumbs(null, 'list', searchResults.tags),
    
    // Contenido relacionado
    relatedContent: {
      articles: apiData.relatedContent?.articles || [],
      videos: apiData.relatedContent?.videos || []
    }
  };
}

// =====================================================
// FUNCIONES DE FORMATEO CORREGIDAS
// =====================================================

function formatImagesArray(images: any[]): string[] {
  if (!images || images.length === 0) {
    return ['/images/placeholder-property.jpg'];
  }
  
  // Usar images_unified de la Edge Function
  return images
    .sort((a, b) => {
      // Imagen principal primero
      if (a.is_main && !b.is_main) return -1;
      if (!a.is_main && b.is_main) return 1;
      // Luego por sort_order
      return (a.sort_order || 0) - (b.sort_order || 0);
    })
    .map(img => img.optimized_url || img.url)
    .filter(Boolean);
}

function getMainImage(images: any[]): string {
  if (!images || images.length === 0) {
    return '/images/placeholder-property.jpg';
  }
  
  const mainImg = images.find(img => img.is_main);
  return mainImg?.optimized_url || mainImg?.url || images[0]?.optimized_url || images[0]?.url || '/images/placeholder-property.jpg';
}

function formatProjectComplete(projectData: any) {
  if (!projectData) return null;
  
  return {
    id: projectData.id,
    name: projectData.name,
    description: projectData.description,
    developer: projectData.developers ? {
      name: projectData.developers.name,
      description: projectData.developers.description,
      logo_url: projectData.developers.logo_url,
      website: projectData.developers.website,
      years_experience: projectData.developers.years_experience,
      total_projects: projectData.developers.total_projects
    } : null,
    status: {
      construction: projectData.construction_status,
      sales: projectData.sales_status,
      completion: projectData.estimated_completion_date
    },
    typologies: projectData.project_typologies?.map((typ: any) => ({
      id: typ.id,
      name: typ.name,
      bedrooms: typ.bedrooms,
      bathrooms: typ.bathrooms,
      area: typ.built_area,
      priceFrom: typ.sale_price_from,
      priceTo: typ.sale_price_to,
      currency: typ.sale_currency || 'USD',
      available: !typ.is_sold_out,
      totalUnits: typ.total_units,
      availableUnits: typ.available_units
    })) || [],
    amenities: projectData.project_amenities?.map((amenity: any) => ({
      name: amenity.amenities?.name || amenity.name,
      icon: amenity.amenities?.icon || 'fas fa-check',
      category: amenity.amenities?.category,
      included: amenity.included !== false
    })) || [],
    paymentPlans: projectData.project_payment_plans?.map((plan: any) => ({
      id: plan.id,
      name: plan.plan_name,
      description: plan.description,
      reservation: plan.reservation_amount,
      reservationCurrency: plan.reservation_currency || 'USD',
      separationPercentage: plan.separation_percentage,
      constructionPercentage: plan.construction_percentage,
      deliveryPercentage: plan.delivery_percentage,
      benefits: plan.benefits,
      isDefault: plan.is_default || false
    })) || [],
    phases: projectData.project_phases?.map((phase: any) => ({
      id: phase.id,
      name: phase.phase_name,
      description: phase.description,
      constructionStart: phase.construction_start,
      estimatedDelivery: phase.estimated_delivery,
      actualDelivery: phase.actual_delivery,
      totalUnits: phase.total_units,
      availableUnits: phase.available_units,
      status: phase.status,
      completionPercentage: phase.completion_percentage
    })) || []
  };
}

function extractGooglePlacesComplete(seoData: any) {
  const places = seoData?.places_enrichment;
  if (!places) return null;
  
  // Ajustar scores por ubicación - zonas premium tienen scores más altos
  let adjustedScore = places.services_score || 0;
  
  // Detectar ubicaciones premium y ajustar score
  const premiumZones = ['piantini', 'naco', 'bella vista', 'serralles', 'gazcue'];
  const locationName = seoData?.location_name?.toLowerCase() || '';
  
  if (premiumZones.some(zone => locationName.includes(zone))) {
    adjustedScore = Math.max(adjustedScore, 85); // Mínimo 85 para zonas premium
    if (locationName.includes('piantini')) adjustedScore = Math.max(adjustedScore, 95);
    if (locationName.includes('naco')) adjustedScore = Math.max(adjustedScore, 90);
    if (locationName.includes('bella vista')) adjustedScore = Math.max(adjustedScore, 88);
  }
  
  return {
    totalServices: places.total_services || 0,
    servicesScore: adjustedScore,
    avgRating: places.avg_rating,
    categories: places.top_categories || [],
    featuredServices: places.featured_services || [],
    hasData: true,
    // Información completa
    servicesSummary: {
      banks: places.categories?.banks || 0,
      hospitals: places.categories?.hospitals || 0,
      schools: places.categories?.schools || 0,
      supermarkets: places.categories?.supermarkets || 0,
      shopping_malls: places.categories?.shopping_malls || 0,
      restaurants: places.categories?.restaurants || 0
    }
  };
}

function extractCoordinates(property: any) {
  // Coordenadas por ubicación específica
  const locationMap: { [key: string]: { lat: number, lng: number } } = {
    'punta cana': { lat: 18.5601, lng: -68.3725 },
    'bavaro': { lat: 18.5467, lng: -68.4104 },
    'naco': { lat: 18.4861, lng: -69.9312 },
    'piantini': { lat: 18.4745, lng: -69.9254 },
    'bella vista': { lat: 18.4696, lng: -69.9411 },
    'manoguayabo': { lat: 18.4861, lng: -70.0037 },
    'santiago': { lat: 19.4517, lng: -70.6970 },
    'distrito nacional': { lat: 18.4682, lng: -69.9279 }
  };
  
  const searchTerms = [
    property.sectors?.name?.toLowerCase(),
    property.cities?.name?.toLowerCase()
  ].filter(Boolean);
  
  for (const term of searchTerms) {
    for (const [location, coords] of Object.entries(locationMap)) {
      if (term.includes(location) || location.includes(term)) {
        return coords;
      }
    }
  }
  
  return { lat: 18.4682, lng: -69.9279 }; // Default Santo Domingo
}

function generateCorrectBreadcrumbs(property: any, type: 'property' | 'list', tags?: any[]) {
  const breadcrumbs = [
    { name: 'Inicio', url: '/', current: false },
    { name: 'Propiedades', url: '/propiedades', current: false }
  ];
  
  if (type === 'property' && property) {
    // Para propiedad individual: Inicio > Propiedades > Comprar > Apartamento > Distrito Nacional > Piantini
    
    // Operación (comprar/alquilar) - CORREGIDO para usar "comprar"
    const operation = property.operation_type === 'rental' ? 'alquilar' : 'comprar';
    breadcrumbs.push({ 
      name: operation.charAt(0).toUpperCase() + operation.slice(1), 
      url: `/${operation}`, 
      current: false 
    });
    
    // Tipo de propiedad
    if (property.category) {
      breadcrumbs.push({ 
        name: property.category, 
        url: `/${operation}/${property.category.toLowerCase()}`, 
        current: false 
      });
    }
    
    // Ciudad
    if (property.cities?.name) {
      breadcrumbs.push({ 
        name: property.cities.name, 
        url: `/${operation}/${property.category?.toLowerCase() || 'apartamento'}/${property.cities.name.toLowerCase().replace(/\s+/g, '-')}`, 
        current: false 
      });
    }
    
    // Sector
    if (property.sectors?.name) {
      breadcrumbs.push({ 
        name: property.sectors.name, 
        url: `/${operation}/${property.category?.toLowerCase() || 'apartamento'}/${property.cities?.name?.toLowerCase().replace(/\s+/g, '-') || 'distrito-nacional'}/${property.sectors.name.toLowerCase().replace(/\s+/g, '-')}`, 
        current: false 
      });
    }
    
    // Propiedad actual
    breadcrumbs.push({ 
      name: property.name, 
      url: property.slug_url, 
      current: true 
    });
    
  } else if (type === 'list' && tags) {
    // Para listado: extraer de tags y usar "comprar" por defecto
    const operation = extractOperationFromTags(tags);
    const propertyType = extractPropertyTypeFromTags(tags);
    const location = extractLocationFromTags(tags);
    
    // Usar "comprar" por defecto en lugar de "venta"
    const breadcrumbOperation = operation?.toLowerCase() === 'venta' ? 'comprar' : (operation?.toLowerCase() || 'comprar');
    
    breadcrumbs.push({ 
      name: breadcrumbOperation.charAt(0).toUpperCase() + breadcrumbOperation.slice(1), 
      url: `/${breadcrumbOperation}`, 
      current: false 
    });
    
    if (propertyType) {
      breadcrumbs.push({ 
        name: propertyType, 
        url: `/${breadcrumbOperation}/${propertyType.toLowerCase()}`, 
        current: false 
      });
    }
    
    if (location) {
      breadcrumbs.push({ 
        name: location, 
        url: `/${breadcrumbOperation}/${propertyType?.toLowerCase() || 'apartamento'}/${location.toLowerCase().replace(/\s+/g, '-')}`, 
        current: true 
      });
    }
  }
  
  return breadcrumbs;
}

function formatPropertyCard(property: any) {
  const pricing = property.pricing_unified || {};
  const images = property.images_unified || [];
  
  return {
    id: property.id,
    title: property.name || '',
    price: pricing.display_price?.formatted || 'Precio a consultar',
    image: getMainImage(images),
    location: formatLocation(property),
    bedrooms: property.bedrooms || 0,
    bathrooms: property.bathrooms || 0,
    built_area: property.built_area || 0,
    parking_spots: property.parking_spots || 0,
    category: property.property_categories?.name || 'Apartamento',
    url: property.slug_url || `/propiedad/${property.id}`,
    is_project: property.is_project || false,
    status: property.property_status || 'Disponible'
  };
}

function formatAgent(agentData: any) {
  if (!agentData) {
    return {
      name: 'CLIC Inmobiliaria',
      phone: '+1-809-555-0100',
      email: 'info@clicinmobiliaria.com',
      position: 'Equipo Comercial',
      whatsapp: 'https://wa.me/18095550100',
      image: '/images/default-agent.jpg',
      rating: 4.9
    };
  }
  
  return {
    name: agentData.name || 'CLIC Inmobiliaria',
    phone: agentData.phone || '+1-809-555-0100',
    email: agentData.email || 'info@clicinmobiliaria.com',
    position: agentData.position || 'Asesor Inmobiliario',
    whatsapp: formatWhatsApp(agentData.phone),
    image: agentData.profile_image || '/images/default-agent.jpg',
    rating: agentData.rating || 4.9,
    code: agentData.external_id || agentData.code
  };
}

function formatAmenities(amenitiesData: any[]) {
  const defaultAmenities = [
    { name: 'Piscina', icon: 'fas fa-swimming-pool' },
    { name: 'Gimnasio', icon: 'fas fa-dumbbell' },
    { name: 'Seguridad 24/7', icon: 'fas fa-shield-alt' },
    { name: 'Parqueo', icon: 'fas fa-car' },
    { name: 'Salón de Eventos', icon: 'fas fa-users' },
    { name: 'Áreas Verdes', icon: 'fas fa-tree' }
  ];
  
  if (!amenitiesData || amenitiesData.length === 0) {
    return defaultAmenities;
  }
  
  const formatted = amenitiesData.map(amenity => ({
    name: amenity.amenities?.name || amenity.name,
    icon: amenity.amenities?.icon || amenity.icon || 'fas fa-check'
  }));
  
  // Completar con amenidades por defecto si hay pocas
  while (formatted.length < 6 && formatted.length < defaultAmenities.length) {
    const missing = defaultAmenities.find(def => 
      !formatted.some(fmt => fmt.name.toLowerCase().includes(def.name.toLowerCase()))
    );
    if (missing) formatted.push(missing);
  }
  
  return formatted;
}

function formatLocation(property: any): string {
  const parts = [
    property.sectors?.name,
    property.cities?.name
  ].filter(Boolean);
  
  return parts.length > 0 ? parts.join(', ') : 'República Dominicana';
}

function formatWhatsApp(phone: string): string {
  if (!phone) return 'https://wa.me/18095550100';
  
  const cleaned = phone.replace(/\D/g, '');
  const number = cleaned.length === 10 ? '1' + cleaned : cleaned;
  return `https://wa.me/${number}`;
}

// =====================================================
// EXTRACTORES DE TAGS
// =====================================================

function extractLocationFromTags(tags: any[]): string | null {
  const locationTag = tags?.find(tag => 
    tag.category === 'ciudad' || tag.category === 'sector' || tag.category === 'provincia'
  );
  return locationTag?.name || null;
}

function extractPropertyTypeFromTags(tags: any[]): string | null {
  const typeTag = tags?.find(tag => tag.category === 'categoria');
  return typeTag?.name || null;
}

function extractOperationFromTags(tags: any[]): string | null {
  const operationTag = tags?.find(tag => tag.category === 'operacion');
  return operationTag?.name || null;
}

// =====================================================
// RESPUESTA VACÍA
// =====================================================

function getEmptyResponse() {
  return {
    type: 'property-list',
    properties: [],
    pagination: {
      currentPage: 1,
      totalCount: 0,
      itemsPerPage: 30,
      totalPages: 0,
      hasMore: false
    },
    search: {
      tags: [],
      location: null,
      propertyType: null,
      operation: null
    },
    seo: {
      title: 'Propiedades no encontradas',
      description: 'No se encontraron propiedades que coincidan con tu búsqueda'
    },
    breadcrumbs: [
      { name: 'Inicio', url: '/' },
      { name: 'Propiedades', url: '/propiedades' }
    ]
  };
}

// =====================================================
// EXPORTS
// =====================================================

export { getSingleProperty, getPropertyList };